import React, { useEffect, useRef } from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import bgImage from "../../../../assets/choose_boringa.png";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const features = [
  "Expert Faculty",
  "Hands-on Workshops",
  "Interactive Learning Sessions",
  "Real-Time Feedback",
  "Access to Exclusive Resources",
  "Post-Course Support",
  "Flexible Scheduling",
  "Networking Opportunities",
  "Customized Study Plans",
];

export const AboutUsSection = (): JSX.Element => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const heading = sectionRef.current?.querySelector(".about-heading");
      const para = sectionRef.current?.querySelector(".about-para");
      const button = sectionRef.current?.querySelector(".about-btn");

      // Combined timeline for synchronized entry
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 85%", // triggers when entering view
        },
      });

      // h2 and paragraph fade-up
      tl.from([heading, para], {
        opacity: 0,
        y: 40,
        duration: 0.8,
        ease: "power3.out",
        stagger: 0.2,
      });

      // Button slight pop + fade
      tl.from(button, {
        opacity: 0,
        scale: 0.9,
        duration: 0.5,
        ease: "back.out(1.7)",
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="entrance-exam"
      className="flex w-full items-center gap-[34px] px-16 py-[100px] relative bg-[#f5f5f5] max-w-7xl overflow-hidden"
    >
      {/* Left: Text Block */}
      <div className="inline-flex flex-col items-start justify-center gap-[41px] relative flex-[0_0_auto]">
        <div className="inline-flex flex-col items-start gap-[11px] relative flex-[0_0_auto]">
          <h2 className="about-heading relative self-stretch mt-[-1.00px] [font-family:'Merriweather',Helvetica] font-bold text-[#ef5134] text-[46.3px] tracking-[0] leading-[normal]">
            Why Choose Borigam Institute?
          </h2>

          <p className="about-para relative w-[560px] [font-family:'Poppins',Helvetica] font-light text-[#4d4d4d] text-2xl tracking-[0] leading-[normal]">
            We provide everything you need to excel
            <br />
            in your entrance exams
          </p>
        </div>

        <Button className="about-btn inline-flex items-center justify-center gap-2.5 px-[21px] py-[15px] relative flex-[0_0_auto] bg-[#ed9821] rounded-[20px] hover:bg-[#d88a1e] h-auto transition-transform duration-300 hover:scale-105">
          <span className="relative w-fit mt-[-1.00px] [font-family:'Poppins',Helvetica] font-normal text-white text-xl tracking-[0] leading-[normal] whitespace-nowrap">
            Learn more
          </span>
        </Button>
      </div>

      {/* Right: Feature Badges (Static) */}
      <div className="flex flex-wrap w-[386px] items-start gap-[9px] relative">
        {features.map((feature, index) => (
          <Badge
            key={index}
            variant="secondary"
            className="inline-flex items-center justify-center gap-2.5 p-[15px] relative flex-[0_0_auto] bg-white rounded-[15px] hover:scale-105 hover:shadow-md transition-transform duration-300"
          >
            <span className="relative w-fit mt-[-2.00px] [font-family:'Poppins',Helvetica] font-medium text-[#646464] text-xs tracking-[0.24px] leading-[normal] whitespace-nowrap">
              {feature}
            </span>
          </Badge>
        ))}
      </div>
    </section>
  );
};
