import React, { useEffect, useRef } from "react";
import { Card, CardContent } from "../../../../components/ui/card";
import enterenceBg from "../../../../assets/enternce_exam_bg.png";
import compass from "../../../../assets/compass.png";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const examData = [
  { name: "NIFT", zIndex: "z-[7]" },
  { name: "NID", zIndex: "z-[6]" },
  { name: "UCEED", zIndex: "z-[5]" },
  { name: "CEED", zIndex: "z-[4]" },
  { name: "NATA", zIndex: "z-[3]" },
  { name: "B.Arch", zIndex: "z-[2]" },
  { name: "BFA", zIndex: "z-[1]" },
  { name: "FDDI", zIndex: "z-0" },
];

export const GallerySection = (): JSX.Element => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const heading = sectionRef.current?.querySelector(".gallery-heading");
      const para = sectionRef.current?.querySelector(".gallery-para");

      // Smooth fade + rise animation for heading and paragraph
      gsap.from([heading, para], {
        opacity: 0,
        y: 40,
        duration: 1.1,
        ease: "power3.out",
        stagger: 0.2,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 85%",
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative flex flex-col w-full items-center justify-center gap-2.5 px-4 md:px-[201px] py-[108px] bg-no-repeat bg-cover overflow-hidden"
      style={{ backgroundImage: `url(${enterenceBg})` }}
    >
      {/* Background overlay */}
      <div className="absolute inset-0 bg-black/60"></div>

      {/* Content container (above overlay) */}
      <div className="relative z-[2] flex flex-col w-full max-w-[1036px] items-center justify-center gap-[52px]">
        {/* Animated Heading and Paragraph */}
        <div className="flex flex-col items-center gap-[15px] w-full">
          <h2 className="gallery-heading [font-family:'Merriweather',Helvetica] font-bold text-white text-4xl md:text-[79.3px] text-center tracking-[0] leading-[normal]">
            Entrance Exams
            <br />
            We Cover
          </h2>

          <p className="gallery-para w-full max-w-[560px] [font-family:'Poppins',Helvetica] font-normal text-white text-lg md:text-2xl text-center tracking-[0] leading-[normal]">
            Comprehensive coaching for all major design and architecture
            entrance examinations
          </p>
        </div>

        {/* Static Cards (No Animation) */}
        <div className="flex items-center justify-center relative w-full flex-wrap gap-4">
          {examData.map((exam, index) => (
            <Card
              key={exam.name}
              className={`${exam.zIndex} group flex flex-col w-[130.63px] h-[135.72px] items-center justify-center
              gap-[26.44px] px-[21.15px] py-[15.87px] relative
              bg-white border-0 rounded-none text-[#646464]
              transition-all duration-500 ease-in-out
              hover:border-b-4 hover:border-[#EF5134] hover:shadow-lg hover:text-[#EF5134]
            `}
            >
              <CardContent className="flex flex-col items-center justify-center gap-[26.44px] p-0 w-full h-full">
                <img
                  src={compass}
                  alt="compass"
                  className="transform transition-transform duration-700 ease-in-out group-hover:rotate-45"
                />
                <div className="flex flex-col w-[103.5px] items-center justify-center gap-[8.31px] relative">
                  <div className="relative w-fit font-medium text-[17px] text-center tracking-[0] leading-[23.3px] whitespace-nowrap transition-all duration-500 ease-in-out group-hover:translate-y-1">
                    {exam.name}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
