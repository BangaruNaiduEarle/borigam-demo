export { EntranceExamsSection } from "./EntranceExamsSection";
