import React, { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import bgImage from "../../../../assets/about_bg.jpg";

gsap.registerPlugin(ScrollTrigger);

export const TeamSection = (): JSX.Element => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;

    // Parallax background movement
    gsap.to(section, {
      backgroundPositionY: "30%", // moves slowly
      ease: "none",
      scrollTrigger: {
        trigger: section,
        start: "top bottom",
        end: "bottom top",
        scrub: true, // smooth scroll-sync
      },
    });

    // Text fade + rise animation
    gsap.fromTo(
      content,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 40%",
        },
      }
    );
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about-us"
      className="relative flex flex-col w-full items-center justify-center gap-2.5 px-4 py-44 bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${bgImage})`, backgroundAttachment: "scroll" }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/60"></div>

      {/* Text content */}
      <div
        ref={contentRef}
        className="flex flex-col w-full max-w-[674px] items-start justify-center gap-[33px] relative"
      >
        <h2 className="relative self-stretch [font-family:'Merriweather',Helvetica] font-bold text-white text-[46.3px] text-center tracking-[0] leading-[normal]">
          About Us
        </h2>

        <p className="relative self-stretch [font-family:'Poppins',Helvetica] font-normal text-white text-sm text-center tracking-[0.28px] leading-[normal]">
          Borigam Coaching Institution, established in 2019, is dedicated to
          nurturing creative minds through exceptional coaching for design and
          architecture entrance exams like NIFT, NID, NATA, B.ARCH, UCEED, and
          CEED. With personalized learning, detailed study material, and regular
          mock tests available both offline and online, we ensure students are
          fully prepared. Our proven success record reflects our commitment to
          helping students achieve their dreams of securing admission to
          prestigious colleges.
        </p>
      </div>
    </section>
  );
};
