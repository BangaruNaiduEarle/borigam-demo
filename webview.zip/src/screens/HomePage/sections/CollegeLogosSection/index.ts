export { CollegeLogosSection } from "./CollegeLogosSection";
