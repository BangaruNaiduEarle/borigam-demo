import React, { useEffect, useRef } from "react";
import { Card, CardContent } from "../../../../components/ui/card";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const statsData = [
  {
    number: "560+",
    description: "Selected in\nDesign Colleges",
  },
  {
    number: "670",
    description: "Selected in\nArchitecture",
  },
  {
    number: "14",
    description: "UCEED IIT\nQualifiers",
  },
  {
    number: "103",
    description: "NIFT Selections",
  },
  {
    number: "24",
    description: "NID Admissions",
  },
  {
    number: "6+ yrs",
    description: "Expertise",
  },
];

export const MissionVisionSection = (): JSX.Element => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray(".stat-card") as HTMLElement[];

      cards.forEach((card, i) => {
        const numberEl = card.querySelector(".stat-number");
        const descEl = card.querySelector(".stat-desc");

        // Stagger each card
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: card,
            start: "top 85%", // triggers when visible
          },
        });

        // Animate card container
        tl.from(card, {
          opacity: 0,
          y: 30,
          duration: 0.6,
          ease: "power3.out",
          delay: i * 0.1,
        })
          // Number pop-in
          .from(
            numberEl,
            {
              opacity: 0,
              scale: 0.9,
              duration: 0.4,
              ease: "power2.out",
            },
            "-=0.3"
          )
          // Description reveal
          .from(
            descEl,
            {
              opacity: 0,
              y: 10,
              duration: 0.5,
              ease: "power2.out",
            },
            "-=0.2"
          );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="flex items-center justify-center flex-wrap gap-8 py-8 px-4"
    >
      {statsData.map((stat, index) => (
        <Card
          key={index}
          className="stat-card flex flex-col w-[157px] h-[157px] items-center justify-center gap-4 px-[19px] py-[42px] bg-white rounded-[100px] border-2 shadow-[0px_11px_12.5px_#00000040]"
        >
          <CardContent className="flex flex-col items-center gap-4 p-0">
            <div className="stat-number [font-family:'Poppins',Helvetica] font-semibold text-[#ef5134] text-[32px] text-center tracking-[0] leading-[normal] whitespace-nowrap">
              {stat.number}
            </div>
            <div className="stat-desc [font-family:'Poppins',Helvetica] font-normal text-[#4d4d4d] text-sm text-center tracking-[0] leading-[normal] whitespace-pre-line">
              {stat.description}
            </div>
          </CardContent>
        </Card>
      ))}
    </section>
  );
};
